package com.milk.recipe.controller;


import com.milk.recipe.model.Recipe;
import com.milk.recipe.service.RecipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recipes")
@CrossOrigin(origins = "http://localhost:8080")  // Allow requests from frontend (Update port if needed)
public class RecipeController {

    @Autowired
    private RecipeService service;

    @PostMapping("/add")
    public Recipe addRecipe(@RequestBody Recipe recipe) {
        System.out.println("Received Recipe:"+recipe);
        return service.addRecipe(recipe);
    }

    @GetMapping("/all")
    public List<Recipe> getAllRecipes() {

        return service.getAllRecipes();
    }
}