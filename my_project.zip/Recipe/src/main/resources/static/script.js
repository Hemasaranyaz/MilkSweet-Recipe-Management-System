// Fetch all recipes
function fetchRecipes() {
    fetch("http://localhost:8080/api/recipes/all")
        .then(response => response.json())
        .then(data => {
            let list = document.getElementById("recipeList");
            list.innerHTML = ""; // Clear previous list

            if (data.length === 0) {
                list.innerHTML = "<li>No recipes found.</li>";
            } else {
                data.forEach(recipe => {
                    list.innerHTML += `<li><strong>${recipe.title}</strong>: ${recipe.ingredients}</li>`;
                });
            }
        })
        .catch(error => {
            console.error("Error fetching recipes:", error);
            alert("Failed to fetch recipes. Please check the server.");
        });
}

// Add a new recipe
function addRecipe() {
    const title = document.getElementById("title").value.trim();
    const ingredients = document.getElementById("ingredients").value.trim();
    const instructions = document.getElementById("instructions").value.trim();

    if (!title || !ingredients || !instructions) {
        alert("Please fill in all fields before adding a recipe.");
        return;
    }

    fetch("http://localhost:8080/api/recipes/add", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ title, ingredients, instructions })
    })
        .then(response => response.json())
        .then(data => {
            alert("Recipe added successfully!");
            fetchRecipes(); // Refresh list
            document.getElementById("title").value = "";
            document.getElementById("ingredients").value = "";
            document.getElementById("instructions").value = "";
        })
        .catch(error => {
            console.error("Error adding recipe:", error);
            alert("Failed to add recipe. Check console for details.");
        });
}
