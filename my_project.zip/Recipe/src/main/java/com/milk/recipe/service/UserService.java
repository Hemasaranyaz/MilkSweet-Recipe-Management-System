package com.milk.recipe.service;

import com.milk.recipe.model.User;
import com.milk.recipe.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public User registerUser(User user) {
        return repository.save(user);
    }

    public boolean validateUser(String username, String password) {
        User user = repository.findByUsername(username);
        return user != null && user.getPassword().equals(password);
    }
}

