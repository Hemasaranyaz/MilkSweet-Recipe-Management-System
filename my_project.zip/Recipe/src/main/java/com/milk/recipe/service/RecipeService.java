package com.milk.recipe.service;
import com.milk.recipe.model.Recipe;
import com.milk.recipe.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RecipeService {
    @Autowired
    private RecipeRepository repository;

    public Recipe addRecipe(Recipe recipe) {
        return repository.save(recipe);
    }

    public List<Recipe> getAllRecipes() {
        return repository.findAll();
    }

   // public Recipe getRecipeById(Long id) {
     //   return repository.findById(id).orElse(null);
   // }

  //  public Recipe updateRecipe(Long id, Recipe recipeDetails) {
    //    Recipe recipe = repository.findById(id).orElse(null);
    //    if (recipe != null) {
    //        recipe.setTitle(recipeDetails.getTitle());
    //        recipe.setIngredients(recipeDetails.getIngredients());
    //        recipe.setInstructions(recipeDetails.getInstructions());
    //        return repository.save(recipe);
      //  }
    //    return null;
    }

  //  public void deleteRecipe(Long id) {
    //    repository.deleteById(id);
    //}

    ////public List<Recipe> searchRecipes(String title) {
        //return repository.findByTitleContainingIgnoreCase(title);
    //}
//}
